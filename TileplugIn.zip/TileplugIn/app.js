import images from "./data.json" assert{type: 'json'}

$("#tile").tile(images);

 