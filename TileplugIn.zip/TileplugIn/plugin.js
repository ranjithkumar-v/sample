jQuery.fn.tile = function(imageSource)
{    

    var largeTile = 1;

     const tile = document.getElementById("tile");
  
    imageSource.forEach(item =>
      {
        if(item.size == "large") 
        {
  
          createTile(item.image_url,item.size);
          largeTile= 1; 
        } 
        if(item.size == "medium")
        {
          if(largeTile == 1 )
          {
            const largeDiv = document.createElement("div");
            largeDiv.classList.add("large-tile","medium-tile-style");
            largeDiv.id = "large";
            tile.append(largeDiv);
            // $(".tile:last").append(largeDiv);  
           largeTile =0;
          }
          createTile(item.image_url,item.size);
        }
      }
      
      )
      
      
      // Function for Tile Creation
      function createTile(source,tileSize)
      {
  
        if(tileSize == "large")
        {
          const largeDiv = document.createElement("div");
          largeDiv.classList.add("large-tile");
          tile.append(largeDiv);
          // $(".tile:last").append(largeDiv);
          var imagetag = createImageElement(source);
          // var url = source;
          // var image = new  Image();
          // image.src =url;
          largeDiv.append(imagetag);
          // $('.large-tile:last').append(image);
        }
  
  
        if(tileSize == "medium")
        {
          const  mediumDiv1 = document.createElement("div");
          mediumDiv1.classList.add("medium-tile");
         $('.large-tile:last').append(mediumDiv1);
          var imageTag =  createImageElement(source);
          mediumDiv1.append(imageTag);
          // $('.medium-tile:last').append(image);
        }
      }
  
  
  function createImageElement(source)
  {
    // var url = source;
    var image = new Image();
    image.src = source;
    return image;
  
  }
  //  function createDiv(tileSize)
  //   {
  //     const div1 = document.createElement("div");
  //     div1.classList.add(tileSize+"-tile");
  //     return div1;

  //   }
  
}