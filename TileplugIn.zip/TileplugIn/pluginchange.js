  jQuery.fn.tile = function(imageSource)

{    

    var count = $(".child:last").children().length;
    //  console.log(count);
    const tile = $("#tile:last");
    imageSource.forEach(item =>
    {
      
        if(item.size === "large") 
        {
         
          createTile(item.image_url,item.size);
        } 
        if(item.size === "medium")
        {

        if(count % 4 == 0 )
        {
          
          const largeDiv = document.createElement("div");
          largeDiv.classList.add("large-tile","child","medium-tile-style");
          tile.append(largeDiv);
        }
      
        createTile(item.image_url,item.size);
        count = $(".child:last").children().length;
        // console.log(count);
        }

      }
      
      )
      
      // Function for Tile Creation

      function createTile(source,tileSize)
      {
  
        if(tileSize === "large")
        {

          
          var  division = createDiv(tileSize);
          var imagetag = createImageElement(source);
          tile.append(division);
          division.append(imagetag);
 
        }
  
  
        if(tileSize === "medium")
        {
         
          var  division = createDiv(tileSize);
          var  imageTag =  createImageElement(source);
          $(".medium-tile-style:last").append(division);
          division.append(imageTag);
        }
      }
// function for image element Creation

    function createImageElement(source)
    {
        // var url = source;
        var image = new Image();
        image.src = source;
        return image;
    
    }

    function createDiv(tileSize)
    {
      const div1 = document.createElement("div");
      div1.classList.add(tileSize+"-tile");
      return div1;

    }
  
}



// const largeDiv = document.createElement("div");
// largeDiv.classList.add("large-tile");

// const  mediumDiv1 = document.createElement("div");
// mediumDiv1.classList.add("medium-tile");