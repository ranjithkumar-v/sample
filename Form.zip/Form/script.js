var username = document.getElementById('name');
var email = document.getElementById('email');
var phoneno = document.getElementById('phoneNo');
var url = document.getElementById('url');
var message = document.getElementById('message');
function validate()
{

    sessionStorage.setItem("Name",username.value)
    sessionStorage.setItem("EmailId",email.value);
    sessionStorage.setItem("PhoneNo",phoneno.value);
    sessionStorage.setItem("URL",url.value);
    sessionStorage.setItem("Message",message.value);
 
}
window.addEventListener("load",setData)
function setData()
{
   if(sessionStorage.length === 0)
   {
     document.getElementById('form-data').style.display =  "none";
   } 
   else

   {

    
    document.getElementById('showName').innerHTML =  sessionStorage.getItem("Name")
    document.getElementById('showEmail').innerHTML =  sessionStorage.getItem("EmailId");
    document.getElementById('showPhone').innerHTML= sessionStorage.getItem("PhoneNo");
    document.getElementById('showURL').innerHTML =  sessionStorage.getItem("URL");
    document.getElementById('showMessage').innerHTML =  sessionStorage.getItem("Message");
    document.getElementById('form-data').style.display =  "block";

   }
}
// window.addEventListener("reload",() =>
// {
//     document.getElementById('form-data').style.display =  "none";

// })
    
