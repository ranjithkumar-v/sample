using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalAssignment
{
    /// <summary>
    /// Public Enum for gender.
    /// </summary>
    public enum Gender{Default,MALE,FEMALE,TRANSEGENDER}
    /// <summary>
    /// Public class for Patient.
    /// </summary>
    public class Patient
    {
        /// <summary>
        /// Private feild for Patient ID
        /// </summary>
        private static int _patientID=0;
        /// <summary>
        /// Public property for patient ID
        /// </summary>
      
        public int PatientID{get;set;}
        /// <summary>
        /// Public property for password.
        /// </summary>
        /// <value></value>
        public string Password{get;set;}
        /// <summary>
        /// Public property for Name
        /// </summary>
        /// <value></value>
        public string Name{get;set;}
        /// <summary>
        /// Public property for Age
        /// </summary>
         public int Age{get;set;}
         /// <summary>
         /// Public property for gender.
         /// </summary>
         /// <value></value>
        public Gender Gender {get;set;}
        /// <summary>
        /// Public Constructor for Patient
        /// </summary>
        /// <param name="password"></param>
        /// <param name="name"></param>
        /// <param name="age"></param>
        /// <param name="gender"></param>

        public Patient(string password,string name,int age,Gender gender)
        {
            ++_patientID;
            PatientID=_patientID;
            Password=password;
            Name=name;
            Age=age;
            Gender=gender;
        }

        public Patient(string data)
        {
            string[]values=data.Split(",");
            _patientID=int.Parse(values[0]);
            PatientID=int.Parse(values[0]);
            Password=values[1];
            Name=values[2];
            Age=int.Parse(values[3]);
            Gender=Enum.Parse<Gender>(values[4]);
        }
        

    }
}