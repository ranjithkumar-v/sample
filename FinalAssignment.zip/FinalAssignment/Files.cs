using System.IO;

namespace FinalAssignment
{
    public static class Files
    {
       //Method to Create the file
        public static void Create()
        {
          if(!Directory.Exists("Hospital"))
          {
            Directory.CreateDirectory("Hospital");
            System.Console.WriteLine("Folder created....");
          }
          else{
            System.Console.WriteLine("Folder already exists..");
          }

          if(!File.Exists("Hospital/PatientDetails.csv"))
          {
         var file1=   File.Create("Hospital/PatientDetails.csv");
            System.Console.WriteLine("File 1 created");
            file1.Close();
          }
          else{
            System.Console.WriteLine("File 1 already created ");
          }
           if(!File.Exists("Hospital/DoctorDetails.csv"))
          {
         var file2=   File.Create("Hospital/DoctorDetails.csv");
            System.Console.WriteLine("File 2 created");
             file2.Close();
          }
          else{
            System.Console.WriteLine("File 2 already created ");
          }
           if(!File.Exists("Hospital/AppointmentDetails.csv"))
          {
         var file3=   File.Create("Hospital/AppointmentDetails.csv");
            System.Console.WriteLine("File 3 created");
             file3.Close();
          }
          else{
            System.Console.WriteLine("File 3 already created ");
          }
          

        }
        
        //Method to Write to files
        public static void WriteToFiles()
        {
         string[]patientDetails=new string[Operation.patientList.Count];
         for(int i=0;i<Operation.patientList.Count;i++)
         {
            patientDetails[i]=Operation.patientList[i].PatientID+","+Operation.patientList[i].Password+","+Operation.patientList[i].Name+","+Operation.patientList[i].Age+","+Operation.patientList[i].Gender;
         }
         File.WriteAllLines("Hospital/PatientDetails.csv",patientDetails);

         string[]doctorDetails=new string[Operation.doctorList.Count];
         for(int i=0;i<Operation.doctorList.Count;i++)
         {
            doctorDetails[i]=Operation.doctorList[i].DoctorID+","+Operation.doctorList[i].Name+","+Operation.doctorList[i].Department;
         }
         File.WriteAllLines("Hospital/DoctorDetails.csv",doctorDetails);

         string[]appointmentDetails=new string[Operation.appointmentList.Count];
         for(int i=0;i<Operation.appointmentList.Count;i++)
         {
            appointmentDetails[i]=Operation.appointmentList[i].AppointmentID+","+Operation.appointmentList[i].PatientID+","+Operation.appointmentList[i].DoctorID+","+Operation.appointmentList[i].Date.ToString("dd/MM/yyyy")+","+Operation.appointmentList[i].Problem;
         }
         File.WriteAllLines("Hospital/AppointmentDetails.csv",appointmentDetails);


        }

        //Method to Read from files
        public static void ReadFromFiles()
        {
          string[]patientDetails=File.ReadAllLines("Hospital/PatientDetails.csv");
          foreach(string data in patientDetails)
          {
            Patient patient =new Patient(data);
            Operation.patientList.Add(patient);
          }

          string [] doctorDetails=File.ReadAllLines("Hospital/DoctorDetails.csv");
          foreach(string data in doctorDetails)
          {
            Doctor doctor=new Doctor(data);
            Operation.doctorList.Add(doctor);
          }
          string []appointmentDetails=File.ReadAllLines("Hospital/AppointmentDetails.csv");
          foreach(string data in appointmentDetails)
          {
            Appointment appointment=new Appointment(data);
            Operation.appointmentList.Add(appointment);
          }
        }
   
    }
}
