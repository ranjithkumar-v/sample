using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalAssignment
{
    /// <summary>
    /// Public Class for Doctor
    /// </summary>
    public class Doctor
    {
        /// <summary>
        /// Private feild for DoctorId.
        /// </summary>
        private static int _doctorID=0;
        /// <summary>
        /// Public property for Doctor ID.
        /// </summary>
        public int DoctorID{get;}
        /// <summary>
        /// Public property for Name.
        /// </summary>
        public string Name{get;set;}
        /// <summary>
        /// Public property for Department.
        /// </summary>
       public string Department{get;set;}
        /// <summary>
        /// Public property for appointment.
        /// </summary>
        public int Appointment{get;set;}
        

        /// <summary>
        /// Public Constructor for Doctor.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="department"></param>
        /// <param name="appointment"></param>
        public Doctor(string name,string department,int appointment)
        {
            ++_doctorID;
            DoctorID=_doctorID;
            Name=name;
            Department=department;
            Appointment=appointment;
        }
        
        public Doctor(string data)
        {
            
            string[]values=data.Split(",");
            _doctorID=int.Parse(values[0]);
            DoctorID=int.Parse(values[0]);
            Name=values[1];
            Department=values[2];
        }
    }
}