using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalAssignment
{
    /// <summary>
    /// Public class for Appointment
    /// </summary>
    public class Appointment
    {
        /// <summary>
        /// Private feild for appointment ID.
        /// </summary>
        private static int _appointmentID=0;
        /// <summary>
        /// Public Property for appointment ID.
        /// </summary>
        
        public int AppointmentID{get;set;}
        /// <summary>
        /// Public property for Patient ID.
        /// </summary>
      
        public int PatientID{get;set;}
        /// <summary>
        /// Public property for doctor ID.
        /// </summary>
      
        public int DoctorID{get;set;}
        /// <summary>
        /// Public Property for DateOfAppointment.
        /// </summary>
      
        public DateTime Date{get;set;}
        /// <summary>
        /// Public property for problem.
        /// </summary>
   
        public string Problem{get;set;}

        /// <summary>
        /// Public Constructor for appointment.
        /// </summary>
        /// <param name="patientID"></param>
        /// <param name="doctorID"></param>
        /// <param name="date"></param>
        /// <param name="problem"></param>
        public Appointment(int patientID,int doctorID,DateTime date,string problem)
        {
            ++_appointmentID;
            AppointmentID=_appointmentID;
            PatientID=patientID;
            DoctorID=doctorID;
            Date=date;
            Problem=problem;
        }

         public Appointment(string data)
        {
             string[]values=data.Split(",");
            _appointmentID=int.Parse(values[0]);
            AppointmentID=int.Parse(values[0]);
            PatientID=int.Parse(values[1]);
            DoctorID=int.Parse(values[2]);
            Date=DateTime.ParseExact(values[3],"dd/MM/yyyy",null);
            Problem=values[4];
        }

    }
}