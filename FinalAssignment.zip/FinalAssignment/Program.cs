﻿﻿using System;
namespace FinalAssignment;
class Program
{
    public static void Main(string[] args)
    {
        
        Operation.Starter();
    }
}