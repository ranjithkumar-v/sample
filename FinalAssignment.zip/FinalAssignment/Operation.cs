using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalAssignment
{
    public delegate void Events();
    public static  class Operation
    {

     public static List<Doctor>doctorList=new List<Doctor>();
     public  static  List<Patient>patientList=new List<Patient>();
     public static  List<Appointment>appointmentList=new List<Appointment>();
      static Patient currentPatient;
      public static event Events start,login,register,subMenu,bookAppointment,viewAppointment,editMyProfile;


        public static void Subscribe()
        {
            //start+=new Events(Files.Create);
            start+=new Events(Files.ReadFromFiles);
            //start+=new Events(AddDefault);
            start+=new Events(MainMenu);
            start+=new Events(Files.WriteToFiles);
            register+=new Events(Register);
            login+=new Events(Login);
            subMenu+=new Events(SubMenu);
            bookAppointment+=new Events(BookAppointment);
            viewAppointment+=new Events(ViewAppointment);
            editMyProfile+=new Events(EditMyProfile);
        }
        public static void Starter()
        {
            Subscribe();
            start();
        }

        //Method for Displaying and calling the methods in MainMenu
        public static void MainMenu()
        {
            int  option;
            do{
            

            System.Console.WriteLine("Enter the option you want\n1.Login\n2.Register\n3.Exit");
            option=int.Parse(Console.ReadLine());
            switch(option)
            {
                case 1:
                {
                   login();
                    break;
                }
                case 2:
                {
                    register();
                    break;
                }
                case 3:
                {
                    System.Console.WriteLine("Exited.");
                    break;
                }
                default:
                {
                    System.Console.WriteLine("Invalid entry.");
                    break;
                }
            }
            }while(option!=3);
            
          


        }

      


         //Method for User Registration
        public static void Register()
        {
            System.Console.WriteLine("Enter your name :");
            string name=Console.ReadLine();
            System.Console.WriteLine("Enter the password :");
            string password=Console.ReadLine();
            System.Console.WriteLine("Enter your age :");
            int age =int.Parse(Console.ReadLine());

            System.Console.WriteLine("Enter you gender :");
            Gender gender=Enum.Parse<Gender>(Console.ReadLine().ToUpper());
            Patient patient=new Patient(password,name,age,gender);
            patientList.Add(patient);
            System.Console.WriteLine("Your Patient ID is :"+patient.PatientID);


        }
        
   
        //Method for User Login
        public static void Login()
        {
            bool flag=false;
            try{
            System.Console.WriteLine("Enter your Patient ID :");
            int patientID=int.Parse(Console.ReadLine());
            System.Console.WriteLine("Enter your password :");
            string password=Console.ReadLine();

            foreach(Patient patient in patientList)
            {
                if(patientID==patient.PatientID&&patient.Password==password)
                {
                    flag=true;

                    System.Console.WriteLine("Sucessfully Logged in.");
                    currentPatient=patient;
                    subMenu();


                }
            }
            if(!flag)
            {
                System.Console.WriteLine("Invalid ID");
            }
            }
            catch(FormatException e)
            {
                System.Console.WriteLine(e.Message);

            }
        }
   
   
         //Method for Displaying and calling the methods in SubMenu
        public static void SubMenu()
        {
            int choice;
            do{
          System.Console.WriteLine("Enter the option you want .\n1.Book Appointment\n2.View Appointment\n3.Edit my profile\n4.Exit");
          choice=int.Parse(Console.ReadLine());
          switch(choice)
          {
            case 1:
            {
                bookAppointment();
                break;
            }
            case 2:
            {
                viewAppointment();
                break;
            }
            case 3:
            {
                editMyProfile();
                break;
            }
            case 4:
            {
                System.Console.WriteLine("Exited from Sub Menu.....");
                break;
            }
            default:
            {
                System.Console.WriteLine("Invalid Entry.........");
                break;
            }
          }
            }while(choice!=4);

       

        }



         //Method to book the appointment
        public static void BookAppointment()
        {
         bool flag=false;
         bool avalaible=false;
           
            try{
            System.Console.WriteLine("Enter your problem");
            string problem = Console.ReadLine();
            System.Console.WriteLine("Please enter the department name correctly you want to see.");
            System.Console.WriteLine("*Anaesthesiology\n*Cardiology\n*Diabetology\n*Neonatology\n*Nephrology");
            string department = Console.ReadLine().ToUpper();
            foreach (Doctor doctor in doctorList)
            {
                if (doctor.Department == department)
                {
                    flag=true;
                    if(doctor.Appointment<2)
                    {
                        avalaible=true;
                   
                                 string line="+........................................................+";
                                 System.Console.WriteLine(line);
                  
                    System.Console.WriteLine("|    Doctor ID   |    Doctor Name     |    Department    |");
                    System.Console.WriteLine(line);
                    System.Console.WriteLine($"|    {doctor.DoctorID.ToString().PadRight(12)}|    {doctor.Name.PadRight(16)}|    {doctor.Department.PadRight(14)}|");
                    System.Console.WriteLine(line);
                    System.Console.WriteLine($"Appointment is confirmed for the date {DateTime.Now.ToString("dd/MM/yyyy")} To book press “Y”, to cancel press “N”");
                char conformation = char.Parse(Console.ReadLine().ToUpper());
                if (conformation == 'Y')
                {
                    System.Console.WriteLine("Appointment Conformed");
                    
                        if (doctor.Department == department)
                        {
                            doctor.Appointment++;
                            Appointment appointment = new Appointment(currentPatient.PatientID, doctor.DoctorID, DateTime.Now, problem);
                            appointmentList.Add(appointment);
                            System.Console.WriteLine("Your appointment Id is :" + appointment.AppointmentID);
                       

                    }
                }
                if (conformation == 'N')
                {
                    System.Console.WriteLine("Appointment not conformed.");
                }
                }
                }
            }
            }
            catch(FormatException e)
            {
                System.Console.WriteLine(e.Message);
            }
            catch(Exception )
            {
                System.Console.WriteLine("Invalid entry");
            }
            if(!flag)
            {
                System.Console.WriteLine("Invalid Department");
            }
            if(!avalaible)
            {
                System.Console.WriteLine("Doctor not avalaible.");
            }
            


           

   
    }
       //Method to View the appointment
       public static void ViewAppointment()
       {
        bool flag=false;
     
                             string line="+............................................................................................+";
                             System.Console.WriteLine(line);
                System.Console.WriteLine("| Appointment ID |   Patient ID  |    Doctor ID    |    Date        |          Problem       |");
                System.Console.WriteLine(line);
        foreach(Appointment appointment in appointmentList)
        {
            if(appointment.PatientID==currentPatient.PatientID)
            {
                flag=true;
                            
                System.Console.WriteLine($"|    {appointment.AppointmentID.ToString().PadRight(12)}|    {appointment.PatientID.ToString().PadRight(12)}|    {appointment.DoctorID.ToString().PadRight(12)}|    {appointment.Date.ToString("dd/MM/yyyy").PadRight(12)}|    {appointment.Problem.ToString().PadRight(20)}|");
            }
        }
        System.Console.WriteLine(line);
        if(!flag)
        {
            System.Console.WriteLine("---->No appointments taken from your ID");
        }

       }
       //Method to edit the profile

       public static void EditMyProfile()
       {
        System.Console.WriteLine("Enter the option you want to edit\n1.Name\n2.Password\n3.Age\n4.Gender");
        int option=int.Parse(Console.ReadLine());
        switch(option)
        {
            case 1:
            {
                try{
                System.Console.WriteLine("Enter the new name to be modified");
                string name=Console.ReadLine();
                currentPatient.Name=name;
                System.Console.WriteLine("The Name changed to :"+currentPatient.Name);
                }
                 catch(FormatException e)
                {
                    System.Console.WriteLine(e.Message+"\nCan't modify the details");
                }
                break;
            }
            case 2:
            {
                try{
                System.Console.WriteLine("Enter the new password to be modified");
                string password=Console.ReadLine();
                currentPatient.Password=password;
                System.Console.WriteLine("Now your new password is :"+currentPatient.Password);
                }
                 catch(FormatException e)
                {
                    System.Console.WriteLine(e.Message+"\n**Can't modify the details");
                }
                

                break;
            }
            case 3:
            {
                try{
                System.Console.WriteLine("Enter the new Age to be modified ");
                int age=int.Parse(Console.ReadLine());
                currentPatient.Age=age;
                System.Console.WriteLine("Now your age is modified to :"+currentPatient.Age);
                }
                catch(FormatException e)
                {
                    System.Console.WriteLine(e.Message+"\nCan't modify the details");
                }
                break;
            }
            case 4:
            {
                try{
                System.Console.WriteLine("Enter the your gender to be modified.");
                Gender gender=Enum.Parse<Gender>(Console.ReadLine().ToUpper());
                currentPatient.Gender=gender;
                System.Console.WriteLine("Now your gender is modified to :"+currentPatient.Gender);
                }
                catch(FormatException e)
                {
                    System.Console.WriteLine(e.Message);

                }
                break;
            }
            default:
            {
                System.Console.WriteLine("Invalid Entry.");
                break;
            }
        }


       }
     

        //Method for Adding Default
        public static void AddDefault()
        {
        Doctor doctor1= new Doctor("Nancy","ANAESTHESIOLOGY",0);
        Doctor doctor2= new Doctor("Andrew","CARDIOLOGY",0);
        Doctor doctor3= new Doctor("Janet","DIABETOLOGY",0);
        Doctor doctor4= new Doctor("Margaret","NEONATOLOGY",0);
        Doctor doctor5= new Doctor("Steven","NEPHROLOGY",0);
        doctorList.Add(doctor1);
        doctorList.Add(doctor2);
        doctorList.Add(doctor3);
        doctorList.Add(doctor4);
        doctorList.Add(doctor5);


        Patient patient1=new Patient("welcome","Robert",40,Gender.MALE);
        Patient patient2=new Patient("welcome","Laura ",36,Gender.FEMALE);
        Patient patient3=new Patient("welcome","Anne ",42,Gender.FEMALE);
        patientList.Add(patient1);
        patientList.Add(patient2);
        patientList.Add(patient3);

        Appointment appointment1=new Appointment(patient1.PatientID,doctor2.DoctorID,new DateTime(2012,03,08),"Heart Problem");
        Appointment appointment2=new Appointment(patient1.PatientID,doctor5.DoctorID,new DateTime(2012,03,08),"Spinal cord injury");
        Appointment appointment3=new Appointment(patient2.PatientID,doctor2.DoctorID,new DateTime(2012,03,08),"Heart attack");
        appointmentList.Add(appointment1);
        appointmentList.Add(appointment2);
        appointmentList.Add(appointment3);
        


        }




}
}