
      document.getElementById('showCategory').innerHTML    =    sessionStorage.getItem("Category");
      document.getElementById('showBookName').innerHTML    =    sessionStorage.getItem("Book");
      document.getElementById('showAuthorName').innerHTML  =    sessionStorage.getItem("AuthorName");
      document.getElementById('showAuthorEmail').innerHTML =    sessionStorage.getItem("AuthorEmail");
    document.getElementById('showPublishedYear').innerText =    sessionStorage.getItem("PublishedYear");
      document.getElementById('showPrice').innerHTML       =    sessionStorage.getItem("Price");