
    var category = document.getElementById('category');
    var bookName = document.getElementById('bookName');
    var authorName = document.getElementById('authorName');
    var authorEmail = document.getElementById('authorEmail');
    var publishedYear = document.getElementById('publishedYear');
    var price = document.getElementById('price');
    var pattern = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
   
    
    bookName.addEventListener("input",checkBookName);
    function checkBookName()
    {
        var bookArray = Array.from(bookName.value);
        var number = false;
        for(let i=0; i < bookArray.length;i++)
        {
            if((bookArray[i] >=0 || bookArray[i] <=9) && bookArray[i] != ' ' )
            {
               number = true;   
            }
        }
        if(bookName.value ===  '')
        {
            document.getElementById('bookNameMessage').innerHTML= "should not be empty";
            bookName.classList.add("error");
            
        } 
        else if(number == true)
        {
            document.getElementById('bookNameMessage').innerHTML= "numberic not allowed";
            bookName.classList.add("error");
        }
  
      else if(bookName.value.length >=50)
      {
        document.getElementById('bookNameMessage').innerHTML = "Book name length should not exceed 50";
        bookName.classList.add("error");

      }
      else
      {
        document.getElementById('bookNameMessage').innerHTML = "";
        bookName.classList.remove("error");
      }
    }
        
    authorName.addEventListener("input",checkauthorName);
    function checkauthorName()
    {
        
        var authorArray = Array.from(authorName.value);
        var number = false;
        var specialChar = false;
        
        for(let i=0; i < authorArray.length;i++)
        {  
            if((authorArray[i] >= 0 || authorArray[i] <=9) && authorArray[i] != ' ') 
            {
               number = true;   
            }
        }
        for(let j = 0;j<authorArray.length;j++)
        {
            if((authorArray [j] >= '!' && authorArray[j] <= '/') ||(authorArray [j] >= ':' && authorArray[j] <= '@') || (authorArray [j] >= '[' && authorArray[j] <= '`') || (authorArray [j] >= '{' && authorArray[j] <= '~'))
            {
                specialChar = true;
            }
        }

        if(authorName.value  === '')
        {
            document.getElementById('authorNameMessage').innerHTML = "should not be empty";
            authorName.classList.add("error");

        }
        else if(number == true)
        {
            document.getElementById('authorNameMessage').innerHTML = "Numeric not allowed";
            authorName.classList.add("error");

    
        }
        else if(specialChar == true)
        {
            document.getElementById('authorNameMessage').innerHTML = "special Character not allowed";
            authorName.classList.add("error");


        }
        else if(authorName.value.length >=50)
        {
            document.getElementById('authorNameMessage').innerHTML = "author name length should not exceed 50";
            authorName.classList.add("error");

        }
       
        else{
            document.getElementById('authorNameMessage').innerHTML = "";
            authorName.classList.remove("error");
        }
    }


    authorEmail.addEventListener("input",checkAuthorEmail)
    function checkAuthorEmail()
    {

    
        if(authorEmail.value == '')
        {
            document.getElementById('authorEmailMessage').innerHTML = "should not be empty";
            authorEmail.classList.add("error");

    
        }
    
        else if (authorEmail.value.match(pattern))
        {
            document.getElementById('authorEmailMessage').innerHTML = "";
            authorEmail.classList.remove("error");

        }
        else{
            document.getElementById('authorEmailMessage').innerHTML = "Enter  valid email address";
            authorEmail.classList.add("error");

        }
    }

    publishedYear.addEventListener("input",checkPublishedYear);
    function checkPublishedYear()
    {
        const date = new Date();
        let CurrentYear = date.getFullYear();
        if(publishedYear.value === "")
        {
            document.getElementById('publishedMessage').innerHTML = "should not be empty";
            publishedYear.classList.add("error");

        }
       else if(publishedYear.value > CurrentYear )
       {
           document.getElementById('publishedMessage').innerHTML="Enter valid published Year";
           publishedYear.classList.add("error");

       }
       else
       {
        document.getElementById('publishedMessage').innerHTML="";
        publishedYear.classList.remove("error");


       }
    }
   
    price.addEventListener("input",checkPrice);
    function checkPrice()
    {
        var priceArray = Array.from(price.value);
        var alphabets = false;
        for(let i=0; i < priceArray.length;i++)
        {  
            if((priceArray[i] >= 'a' && priceArray[i] <= 'z') || (priceArray[i] >= 'A' && priceArray[i] <= 'Z') ) 
            {
               alphabets = true;   
            }
        }


        if(price.value =='')
        {
             document.getElementById('priceMessage').innerHTML = "should not be empty";
             price.classList.add("error");

        }
    
      
      else if(alphabets == true)
       {
        document.getElementById('priceMessage').innerHTML = "Alphabets value not allowed";
        price.classList.add("error");

       }   
       else
       {
        document.getElementById('priceMessage').innerHTML = "";
        price.classList.remove("error");

 
       }
    }


function validate ()
{
    var flag = true;
    if(bookName.value == '')
    {
        document.getElementById('bookNameMessage').innerHTML= "should not be empty";
        bookName.classList.add("error");
        flag  = false;
    }
    if(authorName.value == '')
    {
        document.getElementById('authorNameMessage').innerHTML = "should not be empty";
        authorName.classList.add("error"); 
        flag  = false;

    }
    if(authorEmail.value == '')
    {
        document.getElementById('authorEmailMessage').innerHTML = "should not be empty";
        authorEmail.classList.add("error");
        flag  = false;

    }
    if(publishedYear.value == '')
    {
        document.getElementById('publishedMessage').innerHTML = "should not be empty";
        publishedYear.classList.add("error");
        flag  = false;

    }
    if(price.value == '')
    {
        document.getElementById('priceMessage').innerHTML = "should not be empty";
        price.classList.add("error");
        flag  = false;

    }
    if(flag == false)
    {
        return false;
    }
    else
    {
        sessionStorage.setItem("Category",category.value);
        sessionStorage.setItem("Book",bookName.value);
        sessionStorage.setItem("AuthorName",authorName.value);
        sessionStorage.setItem("AuthorEmail",authorEmail.value);
        sessionStorage.setItem("PublishedYear",publishedYear.value);
        sessionStorage.setItem("Price",price.value);

    }

}
    
    


